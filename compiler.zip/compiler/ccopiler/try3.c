﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>


struct tt1
{
	#include"tt1_struct.c"
};



struct tt1 * tt1_new()
{
	struct tt1 * self= (struct tt1 *)malloc(sizeof(struct tt1));
	
	#include "tt1_new.c"
	
	
	return self;
}


void fun$func()
{
	
	
}


struct n1
{
	int x;
	int y;
};


void func1(struct n1 nn)
{
	
	printf("//// |%d %d\r\n", nn.x, nn.y);
}
int main()
{
	struct tt1* t= tt1_new();
	
	printf("x: %d, y: %d\r\n", t->x, t->y);
	
	func1((struct n1){1,2});
	
	return 0;
}
