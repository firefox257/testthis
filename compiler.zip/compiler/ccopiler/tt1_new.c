﻿

self->x=123;
self->y=246;