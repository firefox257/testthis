﻿const int size=13;
char pre[]="h_";
char h[size][100]={"bool","char","uint1","uint2","uint4","uint8","int1","int2","int4","int8","float4","float8","struct"};

	
	


#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>




uint32_t  strhash(unsigned char *str)
{
    uint32_t hash = 5381;
    int c;

    while (c = *str++)
        hash = ((hash << 5) + hash) + c;

    return hash;
}



int main()
{
	
	for(int i=0; i<size;i++)
	{
		printf("#define %s%s %u\r\n", pre, h[i],strhash(h[i]));
		
	}
	
	
	return 0;
}





