﻿


int x;
int y;
