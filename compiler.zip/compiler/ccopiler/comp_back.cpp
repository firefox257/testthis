﻿


#include <stdint.h>
#include <iostream>
#include <string>
#include <map>
#include <list>


using namespace std;


enum eprim
{
	ebool,
	echar1,
	eint1,
	eint2,
	eint4,
	eint8,
	euint1,
	euint2,
	euint4,
	euint8,
	efloat4,
	efloat8, 
	eclass,
	evoidptr,
	eboolptr,
	echar1ptr,
	eint1ptr,
	eint2ptr,
	eint4ptr,
	eint8ptr,
	euint1ptr,
	euint2ptr,
	euint4ptr,
	euint8ptr,
	efloat4ptr,
	efloat8ptr, 
	eclassptr
	
};

enum esegment
{
	esegmentstart,
	esegmentend
};

enum escope
{
	ebound,
	eunbound
};

enum eaccess
{
	epublic,
	eprotected,
	eprivate
	
};



//map<string, bool> segmentsstart;
//map<string, bool> segmentsend;



class evar
{
	public:
	eprim type;
	string name;
	escope scope;
	eaccess access;
	//bool isfinal; why do this?
	
	
};




class eclass
{
	public:
	string name;
	list<evar> vars;
	
	
	
};

//map<string, eclass> eclasses;

class enamespace
{
	
};



int main()
{
	
	
	
	
	
	return 0;
}
