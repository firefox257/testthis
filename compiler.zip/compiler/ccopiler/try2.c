﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>


void func1(int * i)
{
	*i=((*i)*3)+1;
}



int main()
{
	
	
	int i=0;
	void(*f)(int*)=&func1;
	printf("start\r\n");
	for(int i1=0; i1<8000000;i1++)f(&i);
	printf("stop\r\n");
	
	return 0;
}
