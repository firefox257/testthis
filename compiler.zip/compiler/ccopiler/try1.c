﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>






int main()
{
	
	
	goto lab1;
	
	printf("hi");
	
	lab1:
	
	return 0;
}
