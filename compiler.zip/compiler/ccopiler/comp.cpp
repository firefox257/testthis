﻿
#include <stdint.h>
#include <iostream>
#include <string>
#include <map>
#include <list>
#include <stack>


using namespace std;


uint32_t  strhash(unsigned char *str)
{
    uint32_t hash = 5381;
    int c;

    while (c = *str++)
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash;
}
uint32_t  strhash(string str)
{
	return strhash((unsigned char*)str.c_str());
	
}


enum Errors
{
	ErrorNone,
	ErrorNotANumber
};
string ErrorMsgs[]={"None",
	"Not a number"};

stack<int> filelinecount;

string currentnamespace ="";
string currentclassname="";
string currentfunctionname="";




bool ischaralpha(char c)
{
	return (c>='a' && c<='z') || (c>='A' && c<='Z')||c=='_'||c=='$'||c=='@' ||c=='~';
	
}

bool ischarnum(char c)
{
	
	return c >='0' && c<='9';
}

bool ischarspace(char c)
{
	return c==' '||c=='\t';
}

bool ischarnewline(char c)
{
	return c=='\r'||c=='\n';
}

bool ischaroperator(char c)
{
	
	return c=='+' || c=='-'||c=='*'||c=='/'||c=='='||c=='>'||c=='<'||c=='!'||c=='|'||c=='^'||c=='&'||c=='.'||c==';'||c==':'||c=='#';
}


bool ischarbracket(char c)
{
	
	return c=='{'||c=='}'||c=='['||c==']'||c=='('||c==')';
}

bool isgeneralchar(char c)
{
	
	return !isspace(c);
}


stack<FILE*> includefiles;
void openfile(string name)
{
	FILE* f=fopen(name.c_str(), "r+");
	includefiles.push(f);
	
}
void popfile()
{
	
	FILE * f=includefiles.top();
	fclose(f);
	includefiles.pop();
}

FILE * topfile()
{
	return includefiles.top();
}
bool hasfiles()
{
	return !includefiles.empty();
	
}

void putbackcharfile(FILE * f)
{
	//FILE * f=includefiles.top();
	fseek(f, -1, SEEK_CUR);
}

void skipspaces(FILE * f)
{
	char c;
	
	while(!feof(f))
	{
		
		fread(&c,1,1,f);
		if(!isspace(c))
		{
			putbackcharfile(f);
			return;
		}
		
	}
	
}

void skipnewlines(FILE * f)
{
	char c;
	
	while(!feof(f))
	{
		
		fread(&c,1,1,f);
		if(!ischarnewline(c))
		{
			putbackcharfile(f);
			return;
		}
		
	}
	
}

void readword(FILE *f, std::string & str)
{
	char buff[200];
	int at=0;
	char c;
	while(!feof(f))
	{
		fread(&c,1,1,f);
		if(!ischaralpha(c)&&!isnumber(c))
		{
			buff[at]=0;
			str=buff;
			
			putbackcharfile(f);
			return;
		}
		buff[at]=c;
		at++;
		
	}
	
}
Errors readnumber(FILE *f, string & str)
{
	char buff[200];
	int at=0;
	char c;
	int periodcount=0;
	while(!feof(f))
	{
		fread(&c,1,1,f);
		if(!ischarnum(c)&&c!='.')
		{
			buff[at]=0;
			str=buff;
			
			putbackcharfile(f);
			return ErrorNone;
		}
		if(c=='.')periodcount++;
		if(periodcount>1) return ErrorNotANumber;
		buff[at]=c;
		at++;
		
	}
	return ErrorNone;
	
}
void readoperator(FILE *f, string & str)
{
	char buff[200];
	int at=0;
	char c;
	while(!feof(f))
	{
		fread(&c,1,1,f);
		if(!ischaroperator(c))
		{
			buff[at]=0;
			str=buff;
			
			putbackcharfile(f);
			return;
		}
		buff[at]=c;
		at++;
		
	}
	
}


#define h_bool 2090120081
#define h_char 2090147939
#define h_uint1 276802038
#define h_uint2 276802039
#define h_uint4 276802041
#define h_uint8 276802045
#define h_int1 2090370657
#define h_int2 2090370658
#define h_int4 2090370660
#define h_int8 2090370664
#define h_float4 4256044335
#define h_float8 4256044339



struct elem
{
	
	bool isnuber=false;
	
	
};


void process()
{
	FILE * f=topfile();
	char c;
	
	while(hasfiles())
	{
		while(!feof(f))
		{
			
			
			fread(&c,1,1,f);
			
			putbackcharfile(f);
			
			//todo line count later
			if(ischarspace(c))
			{
				//printf("1");
				skipspaces(f);
			}
			else if(ischarnewline(c))
			{
				printf("newline::\r\n");
				skipnewlines(f);
			}
			else if(ischarbracket(c))
			{
				printf("bracket: %c\r\n", c);
				fread(&c,1,1,f);
			}
			else if(ischaralpha(c))
			{
				
				
				//printf("2");
				string w;
				readword(f, w);
				printf("word: %s\r\n",w.c_str());
				uint32_t h=strhash(w);
				switch(h)
				{
					case h_int4:
					//printf("bla####");
						
					break;	
					
					
				};
				
				
			}
			else if(ischarnum(c))
			{
				//printf("3");
				string w;
				readnumber(f, w);
				printf("number: %s\r\n",w.c_str());
			}
			else if(ischaroperator(c))
			{
				
				//printf("4");
				string w;
				readoperator(f, w);
				printf("operator: %s\r\n",w.c_str());
			}
			else
			{
				//printf("5");
				printf(" |%d|",(int)c);
				fread(&c,1,1,f);
			}
			
		}
		
		popfile();
	}
		
	
}



int main(int nargs, char ** args)
{
	
	openfile("test2.top");
	process();
	
	//if(ischarspace(' '))printf("here");
	
	return 0;
}
