﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define STACKSIZE 1048576
#define CPUCOUNT 4// might not need


#define OpType uint16_t


union Register
{
	int8_t i1;
	int16_t i2;
	int32_t i4;
	int64_t i8;
	
	uint8_t u1;
	uint16_t u2;
	uint32_t u4;
	uint64_t u8;
	
	float f4;
	double f8;
};



enum OP
{
	////--registers
	//hp_,//heap pointer
	
	//// operators	
	nop_,
	addpc_,//add to program counter signed int4
	pushsp_,// create stack with size, set the stack registerto the end
	popsp_,// pop the stack size decrement from stack 
	chsp_,//create heap set to relative stack setntinrefister
	rhsp_,// remove heap from relative stack
	chpr_,// create heap set pointer to register
	rhpr_,//remove heap from register pointer
	movnsp1_, //move const number to relative stack pointer
	movnsp2_, 
	movnsp4_, 
	movnsp8_, 
	
	movnsph1_, //move const number to heap pointer on relative stackpointer
	movnsph2_, 
	movnsph4_, 
	movnsph8_, 
	
	movnrh1_, //move const number to heap pointer on register
	movnrh2_, 
	movnrh4_, 
	movnrh8_, 
	
	movnr1_,//move const number to register
	movnr2_,
	movnr4_,
	movnr8_,
	
	
	printri1_,// print int 8 on register
	printri2_,
	printri4_,
	printri8_,
	
	
	end_	
};




/*typedef struct
{
	int32_t x;
} try1;*/


typedef struct
{
	union Register r[8];
	uint8_t *st;
	uint32_t sp=0;
	uint64_t pc=0;
	
	
} Cpu;

void CpuInit(Cpu* this)
{
	this->st=(uint8_t * )malloc(STACKSIZE);
	
}
void CpuDestruct(Cpu*this)
{
	free(this->st);
	
}


typedef struct
{
	uint64_t size=0;
	uint8_t * d=0;
} Prog;


void ProgInit(Prog* this, uint64_t size)
{
	if(this->d!=0)
	{
		free(this->d);
	}
	this->size = size;
	this->d=(uint8_t *)malloc(size);
	
}

void ProgDestruct(Prog* this)
{
	if(this->d !=0)
	{
		free(this->d);
		this->d=0;
	}
	
}
/////// program memory
void MSetOp(Prog * p, uint64_t * at, OpType op)
{
	(*((OpType*)(p->d+at)))=op;
	(*at)+=sizeof(op);
	
}
void MSetReg(Prog * p, uint64_t * at, uint8_t r)
{
	
	
}

void Mmovnr1(Prog * p, uint64_t * at, int8_t n)
{
	
	MSetOp(p, at, movnr1_);
	
	
}



int main()
{
	Cpu cp1;
	CpuInit(&cp1);
	
	
	
	
	
	
	CpuDestruct(&cp1);
	return 0;
}



