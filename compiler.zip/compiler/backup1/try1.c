﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#pragma pack(1);
/*
void start(int * a)
	{
		static void * *f;//{&&lbl1, &&lbl2, &&lbl3};
		static uint8_t setup=1;
		int i1 =0;
		int i2 =0;
		int at =-1;
		
		if(setup!=1) goto setuplbl;
		
		
		nextlbl:
		at++;
		int ii=a[at];
		//goto *f[ii];
		lbl1:
		{
			i1=1;
		}
		goto nextlbl;
		lbl2:
		{
			i2=2;
		}
		goto nextlbl;
		lbl3:
		return;
		
		setuplbl:
		//f={&&lbl1, &&lbl2, &&lbl3};
		setup=0;
	}
*/	
	
struct try1
{
	int8_t c;
	int32_t i;
	
};
int main()
{
	/*
	lab1:
	
	printf("*");
	void * t = &&lab1;
	goto lab1;*/
	printf("%d\n\r", sizeof(struct try1));
	
	
	goto next;
	
	printf("hi\r\n");
	
	next:
	printf("end\r\n");
	
	return 0;
}
