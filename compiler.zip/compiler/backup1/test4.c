﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#pragma pack(1);




int main()
{
	int32_t i=0;
	for(int32_t i1=0; i1 < 1000000; i1++)
	{
		i=((i*3)+1)%123456;
	}
	printf("%d\r\n", i);
	return 0;
}
