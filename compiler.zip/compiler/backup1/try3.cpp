﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>



struct tt
{
	char c;
	int32_t  i;
}__attribute__((__packed__));

struct tt1
{
	int32_t  i;
	int32_t x;
}__attribute__((__packed__));

union ttt
{
	tt t;
	tt1 t1;
	
};

int main()
{
	ttt t;
	t.t1.x=123;
	printf("%d", sizeof(tt));
	
	return 0;
}
