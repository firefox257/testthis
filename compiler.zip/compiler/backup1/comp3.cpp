﻿

#include <iostream>
#include <stdint.h>
 

using namespace std;


#define STACKSIZE 1048576
#define OpType uint16_t


union Register
{
	int8_t i1;
	int16_t i2;
	int32_t i4;
	int64_t i8;
	
	uint8_t u1;
	uint16_t u2;
	uint32_t u4;
	uint64_t u8;
	
	float f4;
	double f8;
};


/*
enum OP
{
	////--registers
	//hp_,//heap pointer
	
	//// operators	
	nop_,
	addpc_,//add to program counter signed int4
	pushsp_,// create stack with size, set the stack registerto the end
	popsp_,// pop the stack size decrement from stack 
	chsp_,//create heap set to relative stack setntinrefister
	rhsp_,// remove heap from relative stack
	chpr_,// create heap set pointer to register
	rhpr_,//remove heap from register pointer
	movnsp1_, //move const number to relative stack pointer
	movnsp2_, 
	movnsp4_, 
	movnsp8_, 
	
	movnsph1_, //move const number to heap pointer on relative stackpointer
	movnsph2_, 
	movnsph4_, 
	movnsph8_, 
	
	movnrh1_, //move const number to heap pointer on register
	movnrh2_, 
	movnrh4_, 
	movnrh8_, 
	
	movnr1_,//move const number to register
	movnr2_,
	movnr4_,
	movnr8_,
	
	
	printri1_,// print int 8 on register
	printri2_,
	printri4_,
	printri8_,
	
	
	end_	
};
*/
enum OP
{
	
	
	pushst_,//add to the stack
	popst_,//
	
	movnri1_,//move const signed number to register
	movnri4_,
	
	//movnsp4_,//move const number to sp offset 
	
	
	
	printcch1_,// print 1 byte const chracture
	printri1_,// print int 8 on register
	printri4_,
	
	decr_, //decrement by 1
	
	trnzipc_,// test register if not zero if then add 4 bytw signed to pc counter
	
	end_	
};


class Prog
{
	public:
	uint8_t * d=0;
	uint64_t size=0;
	uint64_t at=0;
	
	Prog(uint64_t size)
	{
		this->size=size;
		d=new uint8_t[size];
		
	}
	~Prog()
	{
		if(d!=0)
		{
			delete(d);
			size =0;
			d=0;
			
		}
	}
	
	template<class N>
	N & r()
	{
		uint64_t at1=at;
		at+=sizeof(N);
		return *((N*)(d+at1));
	}
	
	/*uint16_t   op()
	{
		return (*((uint16_t *)(d+at)));
	}*/
	
	
	void reset()
	{
		at =0;
	}
};

struct Cpu
{
	uint8_t * d=0;
	union Register r[8];
	uint8_t st[STACKSIZE];
	uint32_t sp=0;
	uint64_t pc=0;
	Cpu(Prog & p)
	{
		d=p.d;
	}
	void reset()
	{
		sp = pc=0;
	}
	template<class N>
	N & get()
	{
		uint64_t at1=pc;
		pc+=sizeof(N);
		return *((N*)(d+at1));
	}
	uint16_t op()
	{
		return (*((uint16_t *)(d+pc)));
	}
	
};


struct try1
{
	uint32_t x;
	uint8_t c;
	void set(int xx)
	{
		
	}
} __attribute((packed));

/*
struct Mpushsp
{
	OpType op;
	uint32_t n;
	void set(uint32_t num)
	{
		op=OP::pushsp_;
		n=num;
	}
} __attribute((packed));
*/

struct Mpushst
{
	OpType op;
	uint32_t s;
	void set(uint32_t  size)
	{
		op=OP::pushst_;
		s=size;
	}
	static int32_t size()
	{
		return sizeof(Mpushst);
	}
	
} __attribute((packed));
void Fpushst(Cpu & c)
{
	Mpushst & m = c.get<Mpushst>();
	c.sp+=m.s;
}

struct Mpopst
{
	OpType op;
	uint32_t s;
	void set(uint32_t  size)
	{
		op=OP::popst_;
		s=size;
	}
	static int8_t size()
	{
		return sizeof(Mpopst);
	}
	
} __attribute((packed));
void Fpopst(Cpu & c)
{
	Mpopst & m = c.get<Mpopst>();
	c.sp-=m.s;
}


struct Mmovnri1
{
	OpType op;
	uint8_t r;
	int8_t n;
	void set(uint8_t reg, int8_t num)
	{
		op=OP::movnri1_;
		r=reg;
		n=num;
	}
	static int8_t size()
	{
		return sizeof(Mmovnri1);
	}
	
} __attribute((packed));
void Fmovnri1(Cpu & c)
{
	Mmovnri1 & m = c.get<Mmovnri1>();
	c.r[m.r].i1=m.n;
}

struct Mmovnri4
{
	OpType op;
	uint8_t r;
	int32_t n;
	void set(uint8_t reg, int32_t num)
	{
		op=OP::movnri4_;
		r=reg;
		n=num;
	}
	static int8_t size()
	{
		return sizeof(Mmovnri4);
	}
	
} __attribute((packed));
void Fmovnri4(Cpu & c)
{
	Mmovnri4 & m = c.get<Mmovnri4>();
	c.r[m.r].i4=m.n;
}

struct Mprintcch1
{
	OpType op;
	char c;
	void set(char ch)
	{
		op=OP::printcch1_;
		c=ch;
	}
	static int8_t size()
	{
		return sizeof(Mprintcch1);
	}
	
} __attribute((packed));
void Fprintcch1(Cpu & c)
{
	Mprintcch1  & m = c.get<Mprintcch1>();
	printf("%c", m.c);
}

struct Mprintri1
{
	OpType op;
	uint8_t r;
	void set(uint8_t reg)
	{
		op=OP::printri1_;
		r=reg;
	}
	static int8_t size()
	{
		return sizeof(Mprintri1);
	}
	
} __attribute((packed));
void Fprintri1(Cpu & c)
{
	Mprintri1 & m = c.get<Mprintri1>();
	printf("%d", c.r[m.r].i1);
}

struct Mprintri4
{
	OpType op;
	uint8_t r;
	void set(uint32_t reg)
	{
		op=OP::printri4_;
		r=reg;
	}
	static int8_t size()
	{
		return sizeof(Mprintri4);
	}
	
} __attribute((packed));
void Fprintri4(Cpu & c)
{
	Mprintri4 & m = c.get<Mprintri4>();
	printf("%d", c.r[m.r].i4);
}

struct Mdecr
{
	OpType op;
	uint8_t r;
	void set(uint8_t reg)
	{
		op=OP::decr_;
		r=reg;
	}
	static int8_t size()
	{
		return sizeof(Mdecr);
	}
	
} __attribute((packed));
void Fdecr(Cpu & c)
{
	Mdecr & m = c.get<Mdecr>();
	c.r[m.r].i4--;//=c.r[m.r].i4-1;
}

struct Mtrnzipc
{
	OpType op;
	uint8_t r;
	int32_t d;
	void set(uint8_t reg, int32_t inc)
	{
		op=OP::trnzipc_;
		r=reg;
		d =inc;
	}
	static int8_t size()
	{
		return sizeof(Mtrnzipc);
	}
	
} __attribute((packed));
void Ftrnzipc(Cpu & c)
{
	Mtrnzipc & m = c.get<Mtrnzipc>();
	if(c.r[m.r].i4!=0)//=c.r[m.r].i4-1;
	{
		c.pc += m.d;
	}
}


struct Mend
{
	OpType op;
	void set()
	{
		op=OP::end_;
	}
	static int8_t size()
	{
		return sizeof(Mend);
	}
	
} __attribute((packed));
















void (*funptr[])(Cpu&)={Fpushst, Fpopst, Fmovnri1, Fmovnri4,  Fprintcch1, Fprintri1, Fprintri4, Fdecr, Ftrnzipc};
void run(Cpu & c)
{
	c.reset();
	
	int op=-1;
	while(true)
	{
		op=c.op();
		if(op==end_) break;
		funptr[op](c);
	}
	
	cout<<"\r\nprogram ended\r\n";
	
	
}



int main()
{
	
	Prog p(1000000);
	/*p.r<Mmovnr4>().set(0, 3);
	p.r<Mprintri4>().set(0);
	p.r<Mprintcch1 >().set('\n');
	p.r<Mdecr>().set(0);
	p.r<Mprintri4>().set(0);
	p.r<Mprintcch1 >().set('\n');
	p.r<Mend>().set();
	
	*/
	p.r<Mmovnri4>().set(0, 10);
	int a1= p.at;
	p.r<Mprintri4>().set(0);
	p.r<Mprintcch1 >().set('\n');
	p.r<Mdecr>().set(0);
	p.r<Mtrnzipc>().set(0, a1- p.at);
	p.r<Mend>().set();
	
	Cpu cp1(p);
	run(cp1);
	
	
	
	return 0;
}



