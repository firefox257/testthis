﻿#include <iostream>

#include <stdint.h>
 

using namespace std;


#define STACKSIZE 1048576

class 

class opBytes
{
	#define codetype uint16_t
	public:
	
	/*registers
	hp0 pointer to const and global vars
	sp pointer to end of stack
	r0 to r15
	
	in virtualmachine stack has to use heap
	
	
	*/
	
	
	/*notes of operation
	create a stqck that is referenced by 0. 
	This will ve for the global varables
	

	
	
	
	*/
	enum op
	{
		////--registers
		//hp_,//heap pointer
		
		//// operators	
		nop_,
		pushsp_,// create stack with size, set the stack registerto the end
		popsp_,// pop the stack size decrement from stack 
		chsp_,//create heap set to relative stack setntinrefister
		rhsp_,// remove heap from relative stack
		chpr_,// create heap set pointer to register
		rhpr_,//remove heap from register pointer
		movnsp_, //move const number to relative stack pointer
		movnrh
		
	};
	
};






int main()
{
	
	cout << opBytes::pushsp_;
	return 0;
}


