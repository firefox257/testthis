﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <iostream>

using namespace std;


class run
{
	public:
	
	void start(const int * a1)
	{
		int *a=new int[2];
		a[0]=0;
		a[1]=1;
		
		
		void * f[]={&&lbl1, &&lbl2, &&lbl3};
		int i1 =0;
		int i2 =0;
		int at =-1;
		
		nextlbl:
		at++;
		//int  ii=a[at];
		
		goto *f[a[at]];
		
		
		lbl1:
			cout<<1<<endl;
			i1=1;
		//return;
		goto nextlbl;
		
		
		
		
		lbl2:
			cout << 2<< endl;
			i2=2;
		
		//goto nextlbl;
		
		return;
		
		
		lbl3:
			return;
		
		
		
	}
	
};



int main()
{
	/*void * t[]={0};
	t[0]=&&lab1;
	int ii =0;
	
	lab1:
	
	printf("*");
	
	goto *t[ii];
	*/
	
	int a[]={0,0};
	run r;
	r.start(a);
	return 0;
}
