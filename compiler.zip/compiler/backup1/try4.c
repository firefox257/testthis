﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#pragma pack(1);





union Register
{
	int8_t i1;
	int16_t i2;
	int32_t i4;
	int64_t i8;
	
	uint8_t u1;
	uint16_t u2;
	uint32_t u4;
	uint64_t u8;
	
	float f4;
	double f8;
};



int main()
{
	
	union Register r;
	r.f4=3.141;
	printf("%f\r\n", r.f8);
	
	int8_t b=0;
	if(b)printf("here1\r\n");
	
	return 0;
}
