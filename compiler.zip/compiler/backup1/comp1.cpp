﻿#include <iostream>

#include <stdint.h>


using namespace std;

/*
memory types
program memory
stack memory
heap
const memory | part of a large
heap memory, usedfor
constants

sp 
pc

memory pointers are 64 bit to be compatiable to everything
*/
enum opcodes
{ 
	_chp,//. conat heap pointer
	_createheap, // create heap with size to register
	_setpc,
	_addpc,
	_addsp,
	
	
	_ch1r,// set const heap to register this is the global memory locations
	_ch2r,
	_ch4r,
	_ch8r,
	
	_n1ch, // set byte to const heap
	_n2ch,
	_n4ch,
	_n8ch,
	
	
	_n1r,//. set 1 byte to registry
	_n2r,
	_n4r,
	_n8r,
	
	
	
	_m8r,//memomry pointer to registey
	
	
	_new,
	_orb,//print out refistry bool
	_ori1,//print out int 8
	_ori2,
	_ori4,
	_ori8,
	_oru1,// print out unsignes int 8
	_oru2,
	_oru4,
	_oru8,
	_orf4,//printout float32
	_orf8,
	_orc,//print out char
	_ors,//print out c string 
	
	_end,
	_countend
	
};



#define DEFAULTSPSIE 1000000
class stackCode
{
	uint8_t * d=0;
	uint64_t size_=0;
	uint64_t ptr=0;
	public:
	
	stackCode()
	{
		size_=DEFAULTSPSIE;
		d = new uint8_t [DEFAULTSPSIE];
	}
	
	stackCode(uint64_t size)
	{
		size_=size;
		d = new uint8_t [size];
	}
	~stackCode()
	{
		if(d!=0)
		{
			delete(d);
		}
	}
	void size(uint64_t size)
	{
		if(d!=0)
		{
			delete(d);
		}
		size_=size;
		d = new uint8_t[size];
	}
	
	uint64_t size()
	{
		return size_;
	}
	
	void operator +=(int32_t i)
	{
		ptr+=i;
	}
	
	template< class N>
	N val(int32_t at)
	{
		return *((N*)(d+ ptr + at));
	}
	
	template<class N>
	void val(int32_t at, N n)
	{
		
		(*((N*)(d+ ptr + at)))=n;
	}
};

class heapNode
{
	
	public:
	heapNode * next = 0;
};


class heapPtr
{
	void  * p;
	public:
	heapPtr()
	{
		
	}
	
	void operator =(void* ptr)
	{
		p=ptr;
	}
	
	
};






class vm
{
	stackCode sp;
	uint64_t pc=0;
	uint8_t * code=0;
	uint8_t * chp = 0;
	
	union reg
	{
		int8_t i8;
		int16_t i16;
		int32_t i32;
		int64_t i64;
		
		uint8_t u8;
		uint16_t u16;
		uint32_t u32;
		uint64_t u64;
		
		float f;
		double d;
		
		int8_t * i8p;
		int16_t * i16p;
		int32_t * i32p;
		int64_t * i64p;
		
		uint8_t * u8p;
		uint16_t * u16p;
		uint32_t * u32p;
		uint64_t * u64p;
		
		float * fp;
		double * dp;
		
		
	};
	
	reg r[16];
	
	public:
	vm()
	{
	}
	vm(uint64_t spsize)
	{
		sp.size(spsize);
		
	}
	
	
	
	
};





class vmProg
{
	uint8_t *d=0;
	uint64_t size_=0;
	uint64_t pc=0;
	
	template<class N>
	void s(N i)
	{
		*((N*)(d+pc))=i;
		pc+=sizeof(N);
	}
		
	inline void inst(uint16_t i)
	{
		s<uint16_t >(i);
	}
	public:
	vmProg(uint64_t size)
	{
	
		size_=size;
		d=new uint8_t [size];
	}
	~vmProg()
	{
		delete(d);
	}
	void __skippc(int64_t i)
	{
		pc+=i;
	}
	uint64_t __getpc()
	{
		return pc;
	}
	
	
	void setpc(uint64_t at)
	{
		inst(_setpc);
		s(at);
	}
	void addpc(int32_t i)
	{
		inst(_addpc);
		s(i);
	}
	void addsp(int32_t i)
	{
		inst(_addpc);
		s(i);
	}
	
	
	void n1r(bool i, uint8_t r)
	{
		inst(_n1r);
		s(r);
		s(i);
	}
	void n1r(char i, uint8_t r)
	{
		inst(_n1r);
		s(r);
		s(i);
	}
	void n1r(uint8_t  i, uint8_t r)
	{
		inst(_n1r);
		s(r);
		s(i);
	}
	void n1r(int8_t  i, uint8_t r)
	{
		inst(_n1r);
		s(r);
		s(i);
	}
	
	void n2r(uint16_t i, uint8_t r)
	{
		inst(_n2r);
		s(r);
		s(i);
	}
	void n2r(int16_t i, uint8_t r)
	{
		inst(_n2r);
		s(r);
		s(i);
	}
	
	void n4r(uint32_t i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	void n4r(int32_t i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	void n4r(float i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	
	void n8r(uint64_t i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	void n8r(int64_t i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	void n8r(double i, uint8_t r)
	{
		inst(_n4r);
		s(r);
		s(i);
	}
	
};



int main()
{
	
	cout<< _countend <<"\n";
	stackCode sp(256000);
	sp+=4;
	sp.val<int32_t >(0, 123);
	cout<< sp.val<int32_t>(0);
	return 0;
}
