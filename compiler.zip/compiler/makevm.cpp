﻿#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

string filename="testvm.c"

int main()
{
	
	
	
	
	return 0;
}


