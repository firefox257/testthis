﻿#pragma pack(1);
#ifndef RUNPROGRAM_C
#define RUNPROGRAM_C

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "OpStructs.c"
#include "Cpu.c"

struct FileProgram
{
	uint8_t * d;
	uint64_t size;
};

void FileProgram(struct FileProgram * self, char * name)
{
	FILE * fb = fopen(name, "rb");
	char tag[sizeof(filetag)];
	fread(tag, 1,sizeof(filetag),fb);
	
	fread(&(self->size), 1, sizeof(uint64_t), fb);
	//printf("size: %d\n", self->size);
	
	self->d=(uint8_t *) malloc((uint32_t  )(self->size));
	
	/*
	uint8_t b;
	for( uint64_t i=0; i< self->size; i++)
	{
		fread(&b, 1,1,fb);
		self->d[i]=b;
	}
	*/
	
	fread(self->d, 1, self->size, fb);
	
	
}

void _FileProgram(struct FileProgram * self)
{
	
	free(self->d);
	self->size=0;
	self->d=0;
}


#define $atspi1(I) (*((int8_t *)(c->sp+I)))
#define $atspi2(I) (*((int16_t *)(c->sp+I)))
#define $atspi4(I) (*((int32_t *)(c->sp+I)))
#define $atspi8(I) (*((int64_t *)(c->sp+I)))
#define $atspu1(I) (*((uint8_t *)(c->sp+I)))
#define $atspu2(I) (*((uint16_t *)(c->sp+I)))
#define $atspu4(I) (*((uint32_t *)(c->sp+I)))
#define $atspu8(I) (*((uint64_t *)(c->sp+I)))

void run(struct Cpu * c)
{
	
	next:
	
	//void * at = (void *)(c.d+c.pc);
	
	void * at = (void *)(c->pc);
	
	
	switch(*((OpType*)at))
	{
		case addsp_:
		{
			
			struct addsp * m = (struct addsp *)at;
			c->sp+= m->d;
			c->pc+=sizeof(struct addsp);
		}
		goto next;
		case setri4_:
		{
			struct setri4 * m = (struct setri4 *)at;
			c->r[m->r].i4=m->d;
			c->pc+=sizeof(struct setri4);
		}
		goto next;
		case setspi4_:
		{
			struct setspi4 * m = (struct setspi4 *)at;
			*((int32_t *)(c->sp+m->o))=m->d;
			c->pc+=sizeof(struct setspi4);
			
		}
		goto next;
		case printch1_:
		{
			struct printch1* m = (struct printch1 *)at;
			//printf("%d",c.r[m->r].i4);
			putchar(m->d);
			c->pc+=sizeof(struct printch1);
		}
		goto next;
		case printri4_:
		{
			struct printri4 * m = (struct printri4 *)at;
			printf("%d",c->r[m->r].i4);
			c->pc+=sizeof(struct printri4);
		}
		goto next;
		case printspi4_:
		{
			struct printspi4 * m = (struct printspi4 *)at;
			printf("%d",*((int32_t *)(c->sp+m->o)));
			c->pc+=sizeof(struct printspi4);
		}
		goto next;
		case addni4spi4_:
		{
			struct addni4spi4 * m = (struct addni4spi4 *)at;
			(*((int32_t *)(c->sp+m->o)))+=m->d;
			c->pc+=sizeof(struct addni4spi4);
		}
		goto next;
		case mulni4spi4_:
		{
			struct mulni4spi4 * m = (struct mulni4spi4 *)at;
			(*((int32_t *)(c->sp+m->o)))*=m->d;
			c->pc+=sizeof(struct mulni4spi4);
		}
		goto next;
		case modni4spi4_:
		{
			struct modni4spi4 * m = (struct modni4spi4 *)at;
			(*((int32_t *)(c->sp+m->o)))%=m->d;
			c->pc+=sizeof(struct modni4spi4);
		}
		goto next;
		case lni4spi4pc_:
		{
			struct lni4spi4pc * m = (struct lni4spi4pc *)at;
			if($atspi4(m->o)<m->d)
			{
				c->pc+=m->pco;
				goto next;
				
			}
			c->pc+=sizeof(struct lni4spi4pc);
		}
		goto next;
		case end_:
		break;
		
		default:
		printf("not found op code %d\n", *((OpType*)at));
		
		
		
	};
	
}




#endif
