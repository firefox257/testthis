﻿#ifndef LABELTREE_C
#define LABELTREE_C

#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include"Global.c"




struct LabelListNode
{
	void * ptr;
	void * codePtr;
	int8_t type;
	struct LabelListNode * next;
	
}; 
void LabelListNode(struct LabelListNode * self)
{
	self->ptr=-1;
	self->codePtr=-1;
	self->next =0;
	self->type=0;
	
}

void _LabelListNode(struct LabelListNode * self)
{
	//stub in for now
	
}


struct LabelList
{
	struct LabelListNode * h;
	struct LabelListNode * t;
	
};

void LabelList(struct LabelList * self)
{
	self->h=0;
	self->t=0;
	
}
void _LabelList(struct LabelList * self)
{
	struct LabelListNode * n=self->h;
	while(n!=0)
	{
		struct LabelListNode * n1=n->next;
		_LabelListNode(n);
		free(n);
		n=n1;
	}
	self->h=0;
	self->t=0;
}

void LabelListAdd(struct LabelList * self, void * p, void * pc, int8_t type)
{
	
	struct LabelListNode * n=(struct LabelListNode *)malloc(sizeof(struct LabelListNode ));
	LabelListNode(n);
	n->ptr=p;
	n->codePtr=pc;
	n->type=type;
	if(self->h==0)
	{
		self->h=n;
		self->t=n;
	}
	else
	{
		self->t->next=n;
		self->t=self->t->next;
	}
}


struct LabelTreeNode
{
	char *  name;
	void * ptr;
	struct LabelTreeNode * l;
	struct LabelTreeNode * r; 
	struct LabelList list;
	
	
};

void LabelTreeNode(struct LabelTreeNode * self)
{
	self->name=0;
	self->ptr=-1;
	self->l=0;
	self->r=0;
	LabelList(&(self->list));
	
	
}
void _LabelTreeNode(struct LabelTreeNode * self)
{
	_LabelListNode(&(self->list));
	if(self->l!=0)
	{
		_LabelTreeNode(self->l);
		free(self->l);
		self->l=0;
	}
	if(self->r!=0)
	{
		_LabelTreeNode(self->r);
		free(self->r);
		self->r=0;
	}
	if(self->name !=0)
	{
		free(self->name);
		self->name=0;
	}
	
}
struct LabelTree
{
	struct LabelTreeNode * h;
	
};

void LabelTree(struct LabelTree * self)
{
	self->h=0;
}  
void _LabelTree(struct LabelTree * self)
{
	if(self->h!=0)
	{
		_LabelTreeNode(self->h);
		
	}
}

struct LabelTreeNode  ** LabelTreeGetLabelPtr(struct LabelTree * self, char * n)
{
	struct LabelTreeNode **h=&(self->h);
	
	int r=1;
	
	
	while((*h)!=0 && r!=0)
	{
		r =strcmp(n, (*h)->name);
		if(r==0)
		{
			return h;
		}
		else if(r<0)
		{
			h=&((*h)->l);
		}
		else 
		{
			h=&((*h)->r);
		}
	}
	
	//printf("here1: %d\n", 
	if((*h)==0)
	{
		(*h)= (struct LabelTreeNode*)malloc(sizeof(struct LabelTreeNode));
		LabelTreeNode((*h));
		//printf("here1\n");
		realocstr(n, &((*h)->name));
		//(*h)->ptr=p;
	}
	return h;
}


void LabelTreeSetLabel(struct LabelTree * self, char * n, void * p)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	(*h)->ptr=p;
	// set the ptrs in the list
	struct LabelListNode * ll=(*h)->list.h;
	//printf("at here2\n");
	if(ll!=0)
	{
		//printf("here2\n");
		while(ll!=0)
		{
			///here123
			//printf("type here2: %d\n", ll->type);
			//printf("here2: %d\n", p);
			//printf("here2: %d\n", ll->codePtr);
			switch(ll->type)
			{
				case 1:
					*((int8_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 2:
					//printf("here2222\n");
					*((int16_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 4:
					*((int32_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 8:
					*((int64_t *)(ll->ptr))=p-ll->codePtr;
					break;
				
			};
			ll=ll->next;
			
		}//*/
		_LabelList( &((*h)->list));
	
	}
}



int64_t  LabelTreeGet(struct LabelTree * self, char * n)
{
	struct LabelTreeNode ** h=LabelTreeGetLabelPtr(self, n);
	return (*h)->ptr;
	
}


void LabelTreeAddPtr(struct LabelTree * self, char * n, void *  ptr, void * codePtr, int8_t  type)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	if(((int32_t )((*h)->ptr))>=0)
	{
		//tie in the ptr here type
		//printf("type here1: %d\n", type);
		
		//printf("here1: %d\n",(*h)->ptr);
		//printf("here1*: %d\n",codePtr);
		switch(type)
		{
			case 1:
				*((int8_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 2:
				*((int16_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 4:
				*((int32_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 8:
				*((int64_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
		};
		
	}
	else
	{
		LabelListAdd(&((*h)->list), ptr, codePtr, type);
	}	
	
	
}

struct Labels
{
	struct LabelTree gotos;
	struct LabelTree calls;
};

void Labels(struct Labels * self)
{
	LabelTree(&(self->gotos));
	LabelTree(&(self->calls));
}
void _Labels(struct Labels * self)
{
	_LabelTree(&(self->gotos));
	_LabelTree(&(self->calls));
}

void LabelsAddGoto(struct Labels * self, char * name, void * ptr, void * codePtr, int8_t type)
{
	LabelTreeAddPtr(&(self->gotos), name, ptr, codePtr, type);
};

void LabelsAddCall(struct Labels * self, char * name, void * ptr, void * codePtr, int8_t type)
{
	LabelTreeAddPtr(&(self->calls), name, ptr, codePtr, type);
};

void LabelsSetGotoLabel(struct Labels * self, char * name, void * codePtr)
{
	LabelTreeSetLabel(&(self->gotos), name, codePtr);
};

void LabelsSetCallLabel(struct Labels * self, char * name, void * codePtr)
{
	LabelTreeSetLabel(&(self->calls), name, codePtr);
};








/*

int main()
{
	
	int16_t a[1000];
	for(int i=0; i<1000;i++)
	{
		a[i]=0;
	}
	
	
	
	
	struct Labels lab;
	Labels(&lab);
	
	
	
	
	LabelsAddCall(&lab, "for1", a, (void*)20, 2);
	LabelsSetCallLabel(&lab, "for1", (void*)10);
	LabelsSetCallLabel(&lab, "for2", (void*)10);
	
	LabelsAddCall(&lab, "for2", &a[1], (void*)20, 2);
	
	printf("h: %d\n", a[0]);
	printf("h: %d\n", a[1]);
	
	_Labels(&lab);
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
*/
#endif

