﻿#ifndef GLOBAL_C
#define GLOBAL_C

#pragma pack(1);
#include <stdlib.h>

void realocstr(char * s, char ** d)
{
	int si=0;
	while(s[si]!=0)si++;
	if((*d)==0)
	{
		(*d)=(char*)malloc(si);
	}
	else
	{
		(*d)=(char*)realloc((*d), si);
	}
		
	si=0;
	while(s[si]!=0)
	{
		(*d)[si]=s[si];
		si++;
	}
	(*d)[si]=0;
}




#endif


