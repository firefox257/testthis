﻿#pragma pack(1);

#ifndef MAKEPROGRAM_C
#define MAKEPROGRAM_C
#define BUFSIZ 10


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "LabelTree.c"

#include "OpStructs.c"

struct Labels labels;



void MakeProgramBegin (void)
{
 	/* Function Body */
 	Labels(&labels);
}
void MakeProgramEnd (void)
{
 	/* Function Body */
 	_Labels(&labels);
}

struct Program
{
	uint8_t * d;
	uint64_t size;
	//uint64_t at=0;
	uint8_t * at;
};

void Program(struct Program * self, uint64_t s)
{
	
	self->size=s;
	self->d=(uint8_t *)malloc(s);
	self->at=self->d;
}

void _Program(struct Program * self)
{
	free(self->d);
	self->size=0;
	self->d=self->at=0;
	
}

void ProgramWriteFile(struct Program * self, char * name)
{
	
	FILE * fb =fopen(name, "w");
	uint8_t bufff[1000];
	setbuf(fb, bufff);
	fwrite(filetag,1, sizeof(filetag),fb);
	
	uint64_t size =((uint64_t )self->at-(uint64_t )self->d);
	
	printf("sizeis:%d\n", size);
	fwrite(&size,8, 1,fb);
	fwrite((self->d), 1, size, fb);
	//char cc='#';
	//fwrite(&cc,1,1,fb);
	fflush(fb);
	
	fclose(fb);
	
}




void Maddsp(struct Program * p,int32_t d)
{
	struct addsp * m = (struct addsp *)(p->at);
	m->op=addsp_;
	m->d=d;
	p->at+=sizeof(struct addsp);
}
void Msetri4(struct Program * p,uint8_t r,int32_t d)
{
	struct setri4 * m = (struct setri4 *)(p->at);
	m->op=setri4_;
	m->r=r;
	m->d=d;
	p->at+=sizeof(struct setri4);
}
void Msetspi4(struct Program * p,int32_t o,int32_t d)
{
	struct setspi4 * m = (struct setspi4 *)(p->at);
	m->op=setspi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct setspi4);
}
void Mprintch1(struct Program * p,char d)
{
	struct printch1 * m = (struct printch1 *)(p->at);
	m->op=printch1_;
	m->d=d;
	p->at+=sizeof(struct printch1);
}
void Mprintri4(struct Program * p,uint8_t r)
{
	struct printri4 * m = (struct printri4 *)(p->at);
	m->op=printri4_;
	m->r=r;
	p->at+=sizeof(struct printri4);
}
void Mprintspi4(struct Program * p,int32_t o)
{
	struct printspi4 * m = (struct printspi4 *)(p->at);
	m->op=printspi4_;
	m->o=o;
	p->at+=sizeof(struct printspi4);
}
void Maddni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct addni4spi4 * m = (struct addni4spi4 *)(p->at);
	m->op=addni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct addni4spi4);
}
void Mmulni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct mulni4spi4 * m = (struct mulni4spi4 *)(p->at);
	m->op=mulni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct mulni4spi4);
}
void Mmodni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct modni4spi4 * m = (struct modni4spi4 *)(p->at);
	m->op=modni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct modni4spi4);
}
void Mlni4spi4pc(struct Program * p,int32_t o,int32_t d,char * pco)
{
	struct lni4spi4pc * m = (struct lni4spi4pc *)(p->at);
	m->op=lni4spi4pc_;
	m->o=o;
	m->d=d;
	LabelsAddGoto(&labels,pco,&(m->pco), p->at, 4);
	p->at+=sizeof(struct lni4spi4pc);
}

inline void Mgotolabel(struct Program * p, char * name, void * codePtr)
{
	//LabelsSetGotoLabel(&labels, name, codePtr);
	
	LabelsSetGotoLabel(&labels, name, codePtr);
}

inline void Mcalllabel(struct Program * p, char * name, void * codePtr)
{
	//todo push stack for call back
	LabelsSetCallLabel(&labels, name, codePtr);
}

void Mend(struct Program * p)
{
	struct end * m = (struct end*)(p->at);
	m->op=end_;
	p->at+=sizeof(struct end);
}

#endif

