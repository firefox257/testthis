﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#define STACKSIZE 1048576
//#define STACKSIZE 8388608
#include "Cpu.c"
#include "OpStructs.c"
#include "MakeProgram.c"
#include "RunProgram.c"

#include "LabelTree.c"



int main()
{
	
	
	struct Labels $l;
	Labels(&$l);
	struct Program p;
	Program(&p, 1000);
	
	
	/*
	Msetri4(&p, 0, 123);
	Mprintri4(&p, 0);
	Mprintch1(&p,'\n');
	Maddsp(&p, 4);
	Msetspi4(&p, -4, 234);
	Mprintspi4(&p,-4);
	Mprintch1(&p,'\n');
	Maddni4spi4(&p, -4, -10);
	
	Mprintspi4(&p,-4);
	Mprintch1(&p,'\n');
	
	Maddsp(&p, -4);
	Mend(&p);
	*/
	
	Mprintch1(&p,'t');
	Mprintch1(&p,'i');
	Mprintch1(&p,'\n');
	
	Maddsp(&p, 8);
	Msetspi4(&p, -4, 0);
	Msetspi4(&p, -8, 0);
	int64_t at1=p.at;
	//LabelsSetGotoLabel(&$l, "backhere", p.at);
	//Mprintspi4(&p,-4);
	Mmulni4spi4(&p, -8, 3);
	Maddni4spi4(&p, -8, 1);
	Mmodni4spi4(&p, -8, 123456);
	
	Maddni4spi4(&p, -4, 1);
	Mlni4spi4pc(&p, -4, 1000000, at1-((int64_t)p.at));
	Mprintspi4(&p,-8);
	Mprintch1(&p,'\n');
	Maddsp(&p, -8);
	//*/
	Mend(&p);
	
	
	
	struct Cpu c;
	
	Cpu(&c, p.d);
	
	run(&c);
	
	_Cpu(&c);
	
	
	
	ProgramWriteFile(&p, "prog1.bin");
	_Program(&p);
	
	
	_Labels(&$l);
	return 0;
}
