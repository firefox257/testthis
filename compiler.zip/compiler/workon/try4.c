﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

struct try1
{
	int x;
	int y;
	char * name;
	
	
};




int main()
{
	
	
	return 0;
}


