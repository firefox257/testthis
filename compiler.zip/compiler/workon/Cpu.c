﻿#ifndef CPU_C
#define CPU_C

#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#ifndef STACKSIZE
#define STACKSIZE 1048576
//#define STACKSIZE 8388608
#endif

union Register
{
	int8_t i1;
	int16_t i2;
	int32_t i4;
	int64_t i8;
	
	uint8_t u1;
	uint16_t u2;
	uint32_t u4;
	uint64_t u8;
	
	float f4;
	double f8;
	void * p;
};


struct Cpu
{
	uint8_t * d;
	union Register r[8];
	//uint64_t pc=0;
	uint8_t * pc;
	uint8_t * sp;
	uint8_t * st;
	
};

void Cpu(struct Cpu * self, uint8_t * p)
{
	self->d=self->pc=p;
	
	self->st=(uint8_t *)malloc(STACKSIZE);
	self->sp=self->st;
}
void _Cpu(struct Cpu * self)
{
	free(self->st);
	self->st=0;
	self->sp=0;
}



#endif
