﻿#include <stdio.h>
#include <stdint.h>




int main()
{
	void * v1=(void*)10;
	void * v2=(void*)20;
	
	int32_t i=v1-v2;
	printf("%d\n", i);
	
	
	return 0;
}