﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#define STACKSIZE 1048576
//#define STACKSIZE 8388608
#include "OpStructs.c"
#include "Cpu.c"

#include "MakeProgram.c"
#include "RunProgram.c"

#include "LabelTree.c"



int main()
{
	struct Program p;
	Program(&p, 1000);
	MakeProgramBegin();
	
	
	
	Mprintch1(&p,'t');
	Mprintch1(&p,'i');
	Mprintch1(&p,'\n');
	
	Maddsp(&p, 8);
	Msetspi4(&p, -4, 0);
	Msetspi4(&p, -8, 0);
	//int64_t at1=p.at;
	//Mprintspi4(&p,-4);
	
	Mgotolabel(&p, "for1",p.at);
	
	Mmulni4spi4(&p, -8, 3);
	Maddni4spi4(&p, -8, 1);
	Mmodni4spi4(&p, -8, 123456);
	
	Maddni4spi4(&p, -4, 1);
	Mlni4spi4pc(&p, -4, 1000000, "for1");
	Mprintspi4(&p,-8);
	Mprintch1(&p,'\n');
	Maddsp(&p, -8);
	//*/
	Mend(&p);
	
	/*
	
	struct Cpu c;
	
	Cpu(&c, p.d);
	
	run(&c);
	
	_Cpu(&c);
	*/
	
	
	ProgramWriteFile(&p, "prog1.bin");
	_Program(&p);
	
	
	MakeProgramEnd();
	printf("done!!!\n");
	return 0;
}
