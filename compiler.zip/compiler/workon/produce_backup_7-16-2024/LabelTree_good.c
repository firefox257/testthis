﻿#ifndef LABELTREE_C
#define LABELTREE_C

#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>


void realocstr(char * s, char ** d)
{
	int si=0;
	while(s[si]!=0)si++;
	if((*d)==0)
	{
		(*d)=(char*)malloc(si);
	}
	else
	{
		(*d)=(char*)realloc((*d), si);
	}
		
	si=0;
	while(s[si]!=0)
	{
		(*d)[si]=s[si];
		si++;
	}
	(*d)[si]=0;
}


struct LabelListNode
{
	int64_t ptr;
	int64_t codePtr;
	int8_t type;
	struct LabelList * next;
	
}; 
void LabelListNode(struct LabelListNode * self)
{
	self->ptr=-1;
	self->codePtr=-1;
	self->next =0;
	self->type=0;
	
}

void _LabelListNode(struct LabelListNode * self)
{
	//stub in for now
	
}


struct LabelList
{
	struct LabelListNode * h;
	struct LabelListNode * t;
	
};

void LabelList(struct LabelList * self)
{
	self->h=0;
	self->t=0;
	
}
void _LabelList(struct LabelList * self)
{
	struct LabelListNode * n=self->h;
	while(n!=0)
	{
		struct LabelListNode * n1=n->next;
		_LabelListNode(n);
		free(n);
		n=n1;
	}
	self->h=0;
	self->t=0;
}

void LabelListAdd(struct LabelList * self, int64_t p, int64_t pc, int8_t type)
{
	
	struct LabelListNode * n=(struct LabelListNode *)malloc(sizeof(struct LabelListNode ));
	LabelListNode(n);
	n->ptr=p;
	n->codePtr=pc;
	n->type=type;
	if(self->h==0)
	{
		self->h=n;
		self->t=n;
	}
	else
	{
		self->t->next=n;
		self->t=self->t->next;
	}
}


struct LabelTreeNode
{
	char *  name;
	int64_t ptr;
	struct LabelTreeNode * l;
	struct LabelTreeNode * r; 
	struct LabelList list;
	
	
};

void LabelTreeNode(struct LabelTreeNode * self)
{
	self->name=0;
	self->ptr=-1;
	self->l=0;
	self->r=0;
	LabelList(&(self->list));
	
	
}
void _LabelTreeNode(struct LabelTreeNode * self)
{
	_LabelListNode(&(self->list));
	if(self->l!=0)
	{
		_LabelTreeNode(self->l);
		free(self->l);
		self->l=0;
	}
	if(self->r!=0)
	{
		_LabelTreeNode(self->r);
		free(self->r);
		self->r=0;
	}
	if(self->name !=0)
	{
		free(self->name);
		self->name=0;
	}
	
}
struct LabelTree
{
	struct LabelTreeNode * h;
	
};

void LabelTree(struct LabelTree * self)
{
	self->h=0;
}  
void _LabelTree(struct LabelTree * self)
{
	if(self->h!=0)
	{
		_LabelTreeNode(self->h);
		
	}
}

struct LabelTreeNode  ** LabelTreeGetLabelPtr(struct LabelTree * self, char * n)
{
	struct LabelTreeNode **h=&(self->h);
	
	int r=1;
	
	
	while((*h)!=0 && r!=0)
	{
		r =strcmp(n, (*h)->name);
		if(r==0)
		{
			return h;
		}
		else if(r<0)
		{
			h=&((*h)->l);
		}
		else 
		{
			h=&((*h)->r);
		}
	}
	
	//printf("here1: %d\n", 
	if((*h)==0)
	{
		(*h)= (struct LabelTreeNode*)malloc(sizeof(struct LabelTreeNode));
		LabelTreeNode((*h));
		//printf("here1\n");
		realocstr(n, &((*h)->name));
		//(*h)->ptr=p;
	}
	return h;
}


void LabelTreeSetLabel(struct LabelTree * self, char * n, int64_t p)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	(*h)->ptr=p;
	// set the ptrs in the list
	struct LabelListNode * ll=(*h)->list.h;
	if(ll!=0)
	{
		while(ll!=0)
		{
			///here123
			//printf("type here2: %d\n", ll->type);
			//printf("here2: %d\n", p);
			//printf("here2: %d\n", ll->codePtr);
			switch(ll->type)
			{
				case 1:
					*((int8_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 2:
					//printf("here2222\n");
					*((int16_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 4:
					*((int32_t *)(ll->ptr))=p-ll->codePtr;
					break;
				case 8:
					*((int64_t *)(ll->ptr))=p-ll->codePtr;
					break;
				
			};
			ll=ll->next;
			
		}//*/
		_LabelList( &((*h)->list));
	
	}
}



int64_t  LabelTreeGet(struct LabelTree * self, char * n)
{
	struct LabelTreeNode ** h=LabelTreeGetLabelPtr(self, n);
	return (*h)->ptr;
	
}


void LabelTreeAddPtr(struct LabelTree * self, char * n, int64_t  ptr, int64_t codePtr, int8_t  type)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	if((*h)->ptr>=0)
	{
		//tie in the ptr here type
		//printf("type here1: %d\n", type);
		
		
		switch(type)
		{
			case 1:
				*((int8_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 2:
				*((int16_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 4:
				*((int32_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
			case 8:
				*((int64_t *)(ptr))=((*h)->ptr)-codePtr;
				break;
		};
		
	}
	else
	{
		LabelListAdd(&((*h)->list), ptr, codePtr, type);
	}	
	
	
}

struct Labels
{
	struct LabelTree gotos;
	struct LabelTree calls;
};

void Labels(struct Labels * self)
{
	LabelTree(&(self->gotos));
	LabelTree(&(self->calls));
}
void _Labels(struct Labels * self)
{
	_LabelTree(&(self->gotos));
	_LabelTree(&(self->calls));
}

void LabelsAddGoto(struct Labels * self, char * name, int64_t ptr, int64_t codePtr, int8_t type)
{
	LabelTreeAddPtr(&(self->gotos), name, ptr, codePtr, type);
};

void LabelsAddCall(struct Labels * self, char * name, int64_t ptr, int64_t codePtr, int8_t type)
{
	LabelTreeAddPtr(&(self->calls), name, ptr, codePtr, type);
};

void LabelsSetGotoLabel(struct Labels * self, char * name, int64_t codePtr)
{
	LabelTreeSetLabel(&(self->gotos), name, codePtr);
};

void LabelsSetCallLabel(struct Labels * self, char * name, int64_t codePtr)
{
	LabelTreeSetLabel(&(self->calls), name, codePtr);
};









int main()
{
	
	int16_t a[1000];
	for(int i=0; i<1000;i++)
	{
		a[i]=0;
	}
	
	
	
	
	struct Labels lab;
	Labels(&lab);
	
	int64_t aaa=&a[0];
	
	
	LabelsAddCall(&lab, "for1", aaa, 20, 2);
	LabelsSetCallLabel(&lab, "for1", 10);
	LabelsSetCallLabel(&lab, "for2", 10);
	
	LabelsAddCall(&lab, "for2", aaa+2, 20, 2);
	
	printf("h: %d\n", a[0]);
	printf("h: %d\n", a[1]);
	
	_Labels(&lab);
	
	/*
	
	
	struct LabelTree t;
	LabelTree(&t);
	
	
	
	
	int64_t aaa=&a[1];
	
	
	LabelTreeAddPtr(&t, "for1", aaa, 20, 1);
	LabelTreeAddPtr(&t, "for2", aaa+1, 20, 1);
	
	LabelTreeSetLabel(&t, "for1", 10);
	LabelTreeSetLabel(&t, "for2", 23);
	
	printf("h: %d\n", a[1]);
	printf("h: %d\n", a[2]);
	
	*/
	
	return 0;
}

#endif

