﻿


#include <stdint.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <vector>
//#include <map>
#include <string>

using namespace std;

struct OpItemNode
{
	bool isgoto=false;
	bool iscall=false;
	string type;
	string name;
};

struct OpItem
{
	string name;
	vector<OpItemNode> vars;
	vector<string> code;
};
	
class Ops
{
	bool isempty(string & s)
	{
		const char * c=s.c_str();
		int at =0;
		while(c[at]!=0)
		{
			if(c[at] != ' ' && c[at] != '\t') return false;
			at++;
		}
		return true;
	}
	
	bool startsWith(string st, string & s)
	{
		const char * sc = st.c_str();
		const char * c = s.c_str();
		int at=0;
		
		while(c[at]!=0)
		{
			if(c[at] ==' ' || c[at] == '\t')
			{
				//skip
			}
			else if(c[at]==sc[0])
			{
				int at1=0;
				bool pass =true;
				while(sc[at1]!=0)
				{
					if(c[at+at1]!=sc[at1])
					{
						pass =false;
						break;
					}
					at1++;
				}
				if(pass)return true;
				
			}
			at++;
			
		}
		return false;
	}
	
	void replaceChar( string & s, char c1, char c2)
	{
		for(int i =0; i < s.length(); i++)
		{
			if (s[i]==c1) s[i]=c2;
			
		}
		
	}
	
	
	int32_t getnumbytes(string & s1)
	{
		if(s1=="int8_t") return 1;
		if(s1=="int16_t")return 2;
		if(s1=="int32_t")return 4;
		if(s1=="int64_t")return 8;
		return 0;
		
	}
	public:
	//map<string, OpItem> items;
	vector<OpItem> items;
	Ops(const char * filename)
	{
		ifstream f(filename);
		while(!f.eof())
		{
			string s1;
			getline(f, s1);
			
			if( isempty(s1)|| startsWith("//", s1))
			{
				//skip
			}
			else if(startsWith("#op", s1))
			{
				stringstream ss(s1);
				string n;
				ss>>n;
				ss>>n; 
				
				
				items.push_back({});
				
				OpItem & ati = items[items.size()-1]; //items[n];
				ati.name=n;
				
				//cout << "name: "<< n << endl;
				int func=0;//this is struct op definition 1 is code
				while(true)
				{
					getline(f, s1);
					if( isempty(s1)|| startsWith("//", s1))
					{
						//skip
					}
					else if(startsWith("#code", s1))func=1;
					else if(startsWith("#end", s1) )break;
					else if(func == 0)
					{
						replaceChar(s1,';', ' ');
						stringstream ss1(s1);
						
						string t, tn;
						bool isgoto=false;
						bool iscall=false;
						
						ss1>>t;
						if(t.compare("@goto")==0)
						{
							isgoto=true;
							ss1>>t;
						}
						else if(t.compare("@gcall")==0)
						{
							iscall=true;
							ss1>>t;
						}
						ss1>>tn;
						
						
						
						cout << "type: " << t << "name: "<< tn <<endl;
						
						ati.vars.push_back({ isgoto, iscall, t, tn});
					}
					else if(func == 1) ati.code.push_back(s1);
					
					
				}
			}
			
			
		}
		f.close();
	}//end ops()
	
	void printout()
	{
		for(auto & i :items)
		{
			cout << "opname: "<< i.name << endl;
			for(auto & v: i.vars)
			{
				cout << "var "<< v.type << " " << v.name<< endl;
			}
			for(auto & v: i.code)
			{
				cout << "code "<< v << endl;
			}
		}
		
	}
	
	void MakeOpStructs()
	{
		ifstream inf("OpStructs.Model.c");
		ofstream outf("OpStructs.c");
		string s1;
		while(!inf.eof())
		{
			getline(inf, s1);
			if(startsWith("#enum", s1))
			{
				for(auto & i : items)
				{
					outf<<'\t'<<i.name<<"_,"<<endl;
				}
			}
			else if(startsWith("#structs", s1))
			{
				for(auto & i : items)
				{
					outf<<"struct "<<i.name<<endl;
					outf<<'{'<<endl;
					outf<<"\tOpType op;"<<endl;
					for(auto & v: i.vars)
					{
						outf << '\t' << v.type << " " << v.name<< ';'<< endl;
					}
					outf <<"}__attribute((packed));"<<endl;

				}
			}
			else
			{
				outf<<s1<<endl;
			}
			
		}
		inf.close();
		outf.close();
		
	}
	void MakeMakeProgram()
	{
		ifstream inf("MakeProgram.Model.c");
		ofstream outf("MakeProgram.c");
		string s1;
		while(!inf.eof())
		{
			getline(inf, s1);
			if(startsWith("#makecode", s1))
			{
				//auto lastitem = prev(items.end());
				for(auto & i : items)
				{
					//void Maddsp(struct Program * p,int32_t d)
					
					auto last=prev(i.vars.end());
					outf<<"void M"<<i.name<<"(struct Program * p,";
					for(auto & v: i.vars)
					{
						if(v.name==last->name)
						{
							if(v.isgoto)
							{
								
								outf << "char *" << " " << v.name;
							}
							else if(v.iscall)
							{
								outf << "char *" << " " << v.name;
							}
							else
							{
								outf << v.type << " " << v.name;
							}
						}
						else
						{
							if(v.isgoto)
							{
								
								outf << "char *" << " " << v.name << ',';
							}
							else if(v.iscall)
							{
								outf << "char *" << " " << v.name<<',';
							}
							else
							{
								outf << v.type << " " << v.name<< ',';
							}
						}
					}
					outf<<")"<<endl;
					outf<<"{"<<endl;
						
					//struct addsp * m = (struct addsp*)(p->at);
					//m->op=addsp_;
					outf<< "\tstruct "<< i.name<< " * m = (struct " << i.name << " *)(p->at);"<<endl;
					//m->op=addsp_;
					outf<<"\tm->op="<<i.name<<"_;"<<endl;
					for(auto & v: i.vars)
					{
						if(v.isgoto)
						{
							int32_t ntype=getnumbytes(v.type);
							
							
							/*
							outf << "\tint64_t i"<< v.name << "=(int64_t)&(m->"<<v.name<<");\n";
							*/
							
							
							outf << "\tLabelsAddGoto(&labels,"<<v.name<<",&(m->"<<v.name<<"), p->at, "<<ntype<< ");\n";
						}
						else if(v.iscall)
						{
							int32_t ntype=getnumbytes(v.type);
							
							
							/*outf << "\tint64_t i"<< v.name << "=(int64_t)&(m->"<<v.name<<");\n";*/
							outf << "\tLabelsAddCall(&labels,"<<v.name<<",&(m->"<<v.name<<"), p->at, "<<ntype<< ");\n";
						}
						else
						{
							outf<<"\tm->" << v.name<< "="<<v.name<<";"<<endl;
						}
						
						
						
					}
					//p->at+=sizeof(struct addsp);
					outf<<"\tp->at+=sizeof(struct "<<i.name<<");"<<endl;	
						
						
					
					
					outf <<"}"<<endl;

				}
			}
			else
			{
				outf<<s1<<endl;
			}
			
		}
		inf.close();
		outf.close();
		
	}
	
	void MakeRunProgram()
	{
		ifstream inf("RunProgram.Model.c");
		ofstream outf("RunProgram.c");
		string s1;
		while(!inf.eof())
		{
			getline(inf, s1);
			if(startsWith("#switchcode", s1))
			{
				//auto lastitem = prev(items.end());
				for(auto & i : items)
				{
					/*
					
					case addsp_:
					{
			
						struct addsp * m = (struct addsp *)at;
						c.sp+= m->d;
						c.pc+=sizeof(struct addsp);
					}
					goto next;
					*/
					outf <<"\t\tcase "<<i.name<<"_:"<<endl;
					outf<<"\t\t{"<<endl;
					outf<<"\t\t\tstruct "<<i.name<<" * m = (struct "<<i.name<<" *)at;"<<endl;
						
					for(auto & code:i.code)
					{
						outf<<"\t\t"<<code<<endl;
					}
					outf<<"\t\t\tc->pc+=sizeof(struct "<<i.name<<");"<<endl;
					outf<<"\t\t}"<<endl;
					outf<<"\t\tgoto next;"<<endl;
				}
			}
			else
			{
				outf<<s1<<endl;
			}
			
		}
		inf.close();
		outf.close();
		
	}
	
	
	void Make()
	{
		MakeOpStructs();
		MakeMakeProgram();
		MakeRunProgram();
	}
	
};

int main()
{
	Ops op("model.txt");
	op.printout();
	op.Make();
	
	return 0;
}


